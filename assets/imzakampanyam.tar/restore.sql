--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.8 (Debian 11.8-1.pgdg100+1)
-- Dumped by pg_dump version 12.3 (Debian 12.3-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE imzakampanyam;
--
-- Name: imzakampanyam; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE imzakampanyam WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'tr_TR.UTF-8' LC_CTYPE = 'tr_TR.UTF-8';


ALTER DATABASE imzakampanyam OWNER TO postgres;

\connect imzakampanyam

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpython3u; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE OR REPLACE PROCEDURAL LANGUAGE plpython3u;


ALTER PROCEDURAL LANGUAGE plpython3u OWNER TO postgres;

--
-- Name: mail_gonder(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.mail_gonder() RETURNS trigger
    LANGUAGE plpgsql
    AS $$BEGIN
	PERFORM send_email('example@gmail.com','password','smtp.gmail.com',587,NEW.email,'Imza Kampanyam Onay',NEW.mail_onay_url);

	RETURN NEW;
END;
$$;


ALTER FUNCTION public.mail_gonder() OWNER TO postgres;

--
-- Name: send_email(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.send_email(_from text, _password text, smtp text, port integer, receiver text, subject text, send_message text) RETURNS text
    LANGUAGE plpython3u
    AS $$

import smtplib
sender = _from
receivers = receiver
message = ("From: %s\nTo: %s\nSubject: %s\n\n %s"
 % (_from,receiver,subject,send_message))

try:

  smtpObj = smtplib.SMTP(smtp,port)
  smtpObj.starttls()
  smtpObj.login(_from, _password)
  smtpObj.sendmail(sender, receivers,message)
  print ('Successfully sent email')
except SMTPException:
  print ('Error: unable to send email')

return message
$$;


ALTER FUNCTION public.send_email(_from text, _password text, smtp text, port integer, receiver text, subject text, send_message text) OWNER TO postgres;

SET default_tablespace = '';

--
-- Name: user1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user1 (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    ad character varying(100) NOT NULL,
    soyad character varying(100) NOT NULL,
    calisma_unvani character varying(100) NOT NULL,
    mail_onay_url character varying(255)
);


ALTER TABLE public.user1 OWNER TO postgres;

--
-- Name: user1_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user1_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user1_id_seq OWNER TO postgres;

--
-- Name: user1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user1_id_seq OWNED BY public.user1.id;


--
-- Name: user1 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user1 ALTER COLUMN id SET DEFAULT nextval('public.user1_id_seq'::regclass);


--
-- Data for Name: user1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user1 (id, email, ad, soyad, calisma_unvani, mail_onay_url) FROM stdin;
\.
COPY public.user1 (id, email, ad, soyad, calisma_unvani, mail_onay_url) FROM '$$PATH$$/3027.dat';

--
-- Name: user1_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user1_id_seq', 38, true);


--
-- Name: user1 user1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user1
    ADD CONSTRAINT user1_pkey PRIMARY KEY (id);


--
-- Name: user1 mail_gonder1; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER mail_gonder1 AFTER INSERT ON public.user1 FOR EACH ROW EXECUTE PROCEDURE public.mail_gonder();


--
-- PostgreSQL database dump complete
--

